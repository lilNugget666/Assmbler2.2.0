#include "pre_assembler/pre_assembler.h"
#include "data_structs/macro_table.h"
#include "error.h"
#include "helper/utils.h"
#include "data_structs/reserved_table.h"



/*
    implementation of the pre assembler process
    returns a pointer to the output file buffer
*/
FileBuffer* pre_assembler_process(FileBuffer* fb){
    Macro* table;
    FileBuffer* outputfile;
    int i,j;

    table = 0;
    outputfile = fb_new(fb->filename, ".am");
    outputfile->error_flag = fb->error_flag;
    macro_table_init(&table);


    for(i=0; i<fb->count; i++){
        const char* templine;
        const char* p;
        char first_word[MAX_MACRO_NAME], name[MAX_MACRO_NAME];

        templine = fb->lines[i];
        fb->og_current_line_number = i+1;

        p = read_word(templine,first_word,(int)sizeof(first_word));
        if(first_word[0] == '\0'){
            fb_push_line(outputfile,templine,fb->og_current_line_number);
            continue;
        }
          /*detect decleration*/
        if(strcmp(first_word,"mcro") == 0){
            Macro* temp;

            p = read_word(p,name,(int)sizeof(name));
            if(name[0] == '\0'){
                report_error_fb(fb, "Macro requires a name");
                continue;
            }
            else{
                if(!is_only_ws(p)){
                    report_error_fb(fb, "Extra text after macro isnt allowed");
                    continue;
                }
                /*TODO: make sure to check reserved inside valid_macro_name*/
                if(!valid_macro_name(name)){
                    report_error_fb(fb,"Macro name is invalid");
                    continue;
                }
                else if(is_reserved_word(name)){
                    report_error_fb(fb, "illeagal macro name");
                    continue;
                }
                else if(find_macro(table, name)){
                    report_error_fb(fb, "macro already exists");
                }
                else{
                    temp = add_macro(&table, name, fb->og_current_line_number);
                }
                j = i+1;
                temp->definition_line = i+1;
                temp = add_macro(&table, name, fb->og_current_line_number);
                while(strcmp(first_word,"mcroend")!=0 && i<fb->count){

                    macro_add_line(temp,fb->lines[i]);
                }


                p = read_word(p,first_word, (int)(sizeof(first_word)));
                if(!is_only_ws(p)){
                    report_error_fb(fb,"mcroend line should contain only ws");
                    /*TODO : free macro*/
                    
                }
                continue;
            }
        }
        if(strcmp(first_word,"mcroend") == 0){
            report_error_fb(fb,"mcroend with no matching mcro definition");
            continue;
        }
        if(find_macro(table,first_word)!= NULL){
            Macro* temp;
            
            temp = find_macro(table, first_word);
            for(j=0; j< temp->count; j++){
                fb_push_line(outputfile, temp->lines[j],i);
            }
            continue;
        }
        fb_push_line(outputfile,templine,i);
    }
    
    return outputfile;
}

