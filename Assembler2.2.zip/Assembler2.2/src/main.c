
#include "common.h"
#include "file_handler/filebuffer.h"
#include "error.h"
#include "pre_assembler/pre_assembler.h"

static void usage(const char* prog)
{
    fprintf(stderr, "Usage: %s <file1> [file2 ...]\n", prog);
    fprintf(stderr, "  (without extension; the program will read <file>.as)\n");
}
int main(int argc, char** argv){

    int i;
    if(argc<2){
        usage(argv[0]);
        return EXIT_FAILURE;
    }

    for( i=1; i<argc; i++){
        FileBuffer fb;
        FileBuffer* outputbuff;
        char path[TEMP_BUFF_INIT_SIZE];

        
        outputbuff = NULL;

        init_fb(&fb, argv[i],".as");
        make_input_path(path, sizeof(path), fb.filename, fb.ext);
        fb_read_source(&fb,path);

        outputbuff = pre_assembler_process(&fb);

        if(!fb.error_flag && !outputbuff->error_flag){
            fb_write_to_ext(outputbuff, ".am");
        }
        else{
            fprintf(stderr,"No output file prduced for %s due to errors.\n",outputbuff->filename);
        }

        fb_free(outputbuff);
        clear_fb(&fb);

        
    }

    return EXIT_SUCCESS;


}