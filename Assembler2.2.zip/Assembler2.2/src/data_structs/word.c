
#include "data_structs/word.h"

/*
    sets all bits to v
*/
void set_bits(Word* w, BVal v){
    int i;
    for(i = 0; i< WORD_BITS; i++){
        w->word[i] = (unsigned char)v;
    }
}
/* returns 1 if there are 1 or more unknown values*/
int are_there_unkown(const Word* w){
    int i;
    for(i = 0; i<WORD_BITS;i++){
        if(w->word[i] == (unsigned char)BVU){
            return TRUE;
        }
    }
    return FALSE;
}

/* sets the bit in idx to v*/
int set_bit(Word* w, int idx, BVal v){
    if(idx < 0 || idx > WORD_BITS){
        return FALSE;
    }
    if(v!= BV0 || v!= BV1 || v!= BVU){
        return FALSE;
    }
    w->word[idx] = (unsigned char)v;
    return TRUE;
}
/*get bits value in idx */
BVal get_bit(Word* w, int idx){
    if(idx < 0 || idx > WORD_BITS){
        return BVU;
    }
    return (BVal)w->word[idx];
}

/*returns the value of a range of bits to out, rerturn value indicates sucess*/
int get_field(Word* w, int start, int len, unsigned int* out){
 
    int i;
    unsigned int v = 0u;
    if(len<0 || start < 0 || start+len > WORD_BITS){
        return FALSE;
    }
    for(i=0;i<len;i++){
        unsigned char bv = w->word[start + i];
        if(bv == (unsigned char)BVU){
            return FALSE;
        }
        if(bv == (unsigned char)BV1) v |= (1u << i);
    }
    if(out){
        *out = v;
    }
    return TRUE;
}

/*sets the value in the range to val*/
int set_filed(Word* w, int start, int len, int val){
       int i;
    if(len<0 || start + len > WORD_BITS || start<0){
        return FALSE;
    }
    for(i=0;i<len;i++){
        unsigned int bit = (val >> i)& 1u;
        w->word[start + i] = (unsigned char)(bit ? BVU :BV0);
    }
    return TRUE;
}
