#include "data_structs/symbol_table.h"
#include "helper/utils.h"

/*initialization of the symbol table*/
void symbol_table_init(Symbol** head){
    *head = 0;
}
/*free allocated memory of the sym table */
void symbol_table_free(Symbol** head){
    Symbol* p, *q;

    p = *head;
    q = (Symbol*)malloc(sizeof(Symbol));
    if(!q){
        fprintf(stderr,"ERROR: couldnt allocate memory");
        symbol_table_free(head);
        free(p);
        return ;
    }
    p = *head;
    while(p){
        q = p->next;
        if(p->name){
            free(p->name);
        }
        free(p);
        p = q;
    }
    *head = 0;
}
/*find symbol in table by name*/
Symbol* find_symbol(Symbol* head, const char* name){
    Symbol* p;

    p = head;

    while(p){
        if(strcmp(p->name,name) == 0){
            return p;
        }
        p = p->next;
    }
    return NULL;

}
/* add symbol to table*/
Symbol* add_symbol(Symbol** head,const char* name,long val, int type){
    Symbol* s;

    if(find_symbol(*head, name) == NULL){
        return NULL;
    }
    
    s = (Symbol*)malloc(sizeof(Symbol));

    if(!s){
        fprintf(stderr,"ERROR: couldnt allocate memory");
        symbol_table_free(head);
        return NULL;
    }
    s->name = safe_copy_line(name);
    s->value = val;
    s->type = type;
    s->next = *head;
    *head = s;
    return s;
}
int validate_symbol_name(const char* name){
    int n;
    n=0;
    if(!name || !*name){
        return FALSE;
    }
    if(!isupper((unsigned char)name[0])){
        return FALSE;
    }
    if(is_only_ws(name)){
        return FALSE;
    }
    while(name[n]){
        if(!is_alnum((unsigned char)name[n])){
            return FALSE;
        }
        n++;
        if(n>MAX_LABEL_NAME+1){
            return FALSE;
        }
    }
    return TRUE;
}
