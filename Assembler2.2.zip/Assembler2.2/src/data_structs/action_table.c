#include "data_structs/action_table.h"
#include "helper/operand_utils.h"

const Action action_table[NUM_OF_ACTIONS] = {
    { "mov",0,ALL_ADR,ADR_1_3},
    {"cmp",1,ALL_ADR, ALL_ADR},
    {"add",2,ALL_ADR,ADR_1_3},
    {"sub",3,ALL_ADR,ADR_1_3},
    {"lea",4,ADR_1_2,ADR_1_3},
    {"clr" , 5,  NO_ADR, ADR_1_3},
    {"not" , 6, NO_ADR, ADR_1_3},
    {"inc", 7, NO_ADR, ADR_1_3},
    {"dec", 8, NO_ADR, ADR_1_3},
    {"jmp", 9, NO_ADR, ADR_1_3},
    {"bne", 10, NO_ADR, ADR_1_3},
    {"jsr",11, NO_ADR, ADR_1_3},
    {"red",12, NO_ADR, ADR_1_3},
    {"prn",13,NO_ADR, ALL_ADR},
    {"rts",14,NO_ADR, NO_ADR},
    {"stop", 15, NO_ADR,NO_ADR}
};

const Action* find_action(const char* name){
    int i;
    if(!name){
        return NULL;
    }
    for( i = 0; i<NUM_OF_ACTIONS;i++){
        if(strcmp(action_table[i].name,name) == 0){
            return &action_table[i];
        }
    }
    return NULL;
}

int is_opcode(const char* s){
    return find_action(s) != NULL;
}
int adr_mask_bit(OperandAdressing m){
    switch(m){
    case OP_ADR_IMMEDIATE: return IMMEDIATE_ADR;
    case OP_ADR_DIRECT:    return DIRECT_ADR;
    case OP_ADR_MAT:       return MAT_ADR;
    case OP_ADR_REG:       return REG_ADR;
    default:               return 0;
    }
}
