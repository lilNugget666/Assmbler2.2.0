#ifndef ERROR_H
#define ERROR_H

#include "file_handler/filebuffer.h"

/*
    prints and reports the error. (doesnt stop the run)
    
*/
int report_error_fb(FileBuffer* fb, const char* msg);



#endif