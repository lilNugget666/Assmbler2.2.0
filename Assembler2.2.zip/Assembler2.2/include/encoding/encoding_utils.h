
#ifndef ENCODING_UTILS_H
#define ENCODING_UTILS_H

#include "data_structs/word.h"
#include "encoding/encoding_layout.h"
#include "helper/operand_utils.h"



#endif