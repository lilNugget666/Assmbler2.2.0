#ifndef FILEBUFFER_H
#define FILEBUFFER_H

#include <stdio.h>
/*
    Represents a file
    lines - file lines
    count - number of lines in the file 
    capacity - the size allocated for the buffer lines
    og_current_line_number - the actual number of the line in the input file
    error_flag - indicates errors so output files wont be created
    filename - the name of the file 
    ext - the extension of the file
*/
typedef struct{
    char** lines;
    int count;
    int capacity;
    int og_current_line_number;
    int error_flag;
    const char* filename;
    const char* ext;
    
    
}FileBuffer;

/*
    initializes the buffer with default values
*/
int init_fb(FileBuffer* fb, const char* filename, const char* ext);
/*
    clears the lines and details in the buffer
*/
void clear_fb(FileBuffer* fb);


/*
    creates a new file buffer with ext and filename
*/
FileBuffer* fb_new(const char* filename, const char* ext);
/*
    frees allocated memory of buffer
*/
void fb_free(FileBuffer* fb);
/*
    add a new line to the buffer
*/
int fb_push_line(FileBuffer* fb, const char* srcline, int og_line_number);

/*
    read file into buffer
*/
int fb_read_source(FileBuffer* fb, const char* filepath);
/*
    attaches the file name and ext in a format
*/
void make_input_path(char* out, size_t out_size, const char* basename, const char* ext);

/*
    writes buffer conent into a .ext file
*/
int fb_write_to_ext(FileBuffer* fb, const char* ext);
#endif