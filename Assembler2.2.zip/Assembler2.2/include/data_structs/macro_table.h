#ifndef MACRO_TABLE_H
#define MACRO_TABLE_H

#include "common.h"

/*
    representation of a macro
    definition line is the line in the input file where it was defined
*/
typedef struct Macro{
    char* name;
    char** lines;
    int count;
    int capacity;
    long definition_line;
    struct Macro* next;
}Macro;

/*
    initialization of the table with default values
*/
void macro_table_init(Macro** head);
void macro_table_free(Macro** head);
/*
    locate a macro in the table by its name
    returns a pointer to it if found
*/
Macro* find_macro(Macro* head, const char* name);
/*
    inserts a macro to the table 
*/
Macro* add_macro(Macro** head, const char* name, long definition_line);
/*
    adds a line to the macro lines
*/
int macro_add_line(Macro* mcro, const char* src);


#endif