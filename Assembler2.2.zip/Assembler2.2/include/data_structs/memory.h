#ifndef MEMORY_H
#define MEMORY_H

#include "common.h"
#include "data_structs/word.h"

#define MEM_CAP 256
#define IC_START_POINT 100

typedef struct{
    Word memory[MEM_CAP];
    long IC;
    long DC;
    long ICF;
    long DCF;

}Memory;

/*initialize memory*/
void mem_init(Memory* m);
/*free memory*/
void mem_clear(Memory* m);

/*reserve words for code parts, advances ic*/
int mem_reserve_code(Memory* m, int words);

/*returns the code at idx (idx+100)*/
Word* mem_code_at(Memory* m , int idx);
/*returns the data at idx*/
Word* mem_data_at(Memory* m, int idx);

/*insert a value into the memory*/
int mem_insert_data_val(Memory* mem, unsigned int val);

/*get code img*/
long mem_code_img(const Memory* m);
/*get data img*/
long mem_data_img(const Memory* m);


#endif