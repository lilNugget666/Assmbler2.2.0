#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H
#include "common.h"

/*Symbol type enum*/
enum{
    CODE_SYMBOL = 1,
    DATA_SYMBOL = 2,
    EXTERN_SYMBOL =3,
    ENTRY_SYMBOL = 4
};

/*
    represents a symbol
    name is for the name of the lable
    value is for the mem address
    type is the sym type
*/
typedef struct Symbol{
    char* name;
    long value; 
    int type;
    struct Symbol* next;
    
}Symbol;

/*initialization of the symbol table*/
void symbol_table_init(Symbol** head);
/*free allocated memory of the sym table */
void symbol_table_free(Symbol** head);
/*find symbol in table by name*/
Symbol* find_symbol(Symbol* head, const char* name);
/* add symbol to table*/
Symbol* add_symbol(Symbol** head,const char* name,long val, int type);
/*checks if the name itself is valid (doesnt check if it already exists in the table)*/
int validate_symbol_name(const char* name);

#endif