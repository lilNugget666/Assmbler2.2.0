#include "../include/common.h"
#include "../include/error_a.h"

int report_error_fb(FileBuffer* fb, const char* msg){
    fb->error_flag = TRUE;
    fprintf(stderr, "ERORR: %s:%d %s \n", fb->filename, fb->og_current_line_number,msg);
    fputc('\n',stderr);
    return TRUE;
}
int report_error_fb(FileBuffer* fb, const char* msg, int i){
    fb->error_flag = TRUE;
    fprintf(stderr, "ERORR: %s:%d %s \n", fb->filename, i ,msg);
    fputc('\n',stderr);
    return TRUE;
}