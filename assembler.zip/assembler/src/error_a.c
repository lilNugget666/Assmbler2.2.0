#include "../include/common.h"
#include "../include/error_a.h"

int report_error_fb(FileBuffer* fb, const char* msg){
    fb->error_flag = TRUE;
    fprintf(stderr, "ERORR:%s in file %s on line %d",msg, fb->filename, fb->og_current_line_number);
    fputc('\n',stderr);
    return TRUE;
}