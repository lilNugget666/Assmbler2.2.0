#include "../../include/common.h"
#include "../../include/error_a.h"


/*
copies a line and allocates memory if needed
*/
char* safe_copy_line(const char* s){
    size_t n;
    char* p;
    n = strlen(s)+1;
    p = (char*)malloc(n);
    if(!p){
        fprintf(stderr,"ERROR: couldnt allocate memory\n");
        return NULL;
        /*TODO: shut everything down*/
    }

    memcpy(p,s,n);
    return p;

}
/*skips leading white spaces*/
const char* skip_ws(const char* line){
    const unsigned char* p = (const unsigned char*)line;
    while(*p && isspace(*p)){
        p++;
    }
    return (const char*)p;
}
/*checks if a line contains only white spaces*/
int is_only_ws(const char* line){
    const unsigned char* p = (const unsigned char*)line;
    while(*p){
        if(!isspace(*p)){
            return FALSE;
        }
        p++;
    }
    return TRUE;
}
/*reada the next word in the line (stoppes at ws)*/
const char* read_word(const char* line, char* out, int out_size){
    const unsigned char* p;
    int n;
    if(!line || !out || out_size <=0){
        return line;
    }
    p = (const unsigned char*)skip_ws(line);
    n=0;

    out[n] = '\0';

    while(*p && !isspace(*p) && n < out_size-1){
        out[n++] = (char)*p++;
    }
    out[n] = '\0';
    return(const char*)p;
    
}
/*reads until a specific char*/
char* read_till_char(const char* line,char sign){
    
    const char* p;
    size_t n;
    char* out;
    p = line;
    while(*p && *p != sign){
        p++;
    }
    n = (size_t)(p-line);
    out = (char*)malloc(n+1);
    if(!out){
        fprintf(stderr, "ERROR: couldnt allocate memory");
        free(out);
        return NULL;
    }
    if(n){
        memcpy(out,line,n);
    }
    out[n] = '\0';
    return out;
}

/*checks if c is a letter*/
int is_alpha(int c){
    return (c>= 'A' && c<= 'Z') || (c>='a' && c<='z');
}
/*checks if c is a numebr*/
int is_num(int c){
    return (c>='0' && c<='9');
}

int is_alnum(int c){
    return is_alpha(c) || is_num(c) || c == '_';
}

/*validates a macro name*/
int valid_macro_name(const char* name){

    int n;
    n =0;
    if(!name|| !is_alpha((unsigned char)name[n])){
        return FALSE;
    }
    n=1;
    while(name[n]){
        if(!is_alnum(name[n])){
            return FALSE;
        }
        n++;
        if(n>31){
            return FALSE;
        }

    }
    return (n>0);
}
