
#include "../../include/helper/operand_utils.h"
#include "../../include/helper/utils.h"
#include "../../include/data_structs/reserved_table.h"
#include "../../include/data_structs/symbol_table.h"
#include "../../include/common.h"
/*splits the operands into an array (out)*/
int parse_operands(const char* s, char out[][MAX_LINE_LENGTH],int max_ops, int* out_count){

    const char* p;
    int n;
    p = skip_ws(s);
    n=0;
    if(out_count){
        *out_count = 0;
    }
    if(*p == '\0'){
        if(out_count){
            *out_count = 0;
            return TRUE;
        }
    }

    while (*p && n < max_ops)
    {
        const char* start;
        const char* q;
        int len;

        start = p;
        len = 0;

        while(*p && *p!=','){
            p++;
        }
        q = p;
        while(q > start && isspace((unsigned char)q[-1])){
            q--;
        }
        len = (int)(q-start);

        if(len <= 0){
            return FALSE;
        }
        if(len >= MAX_LINE_LENGTH){
            len = MAX_LINE_LENGTH -1;
        }
        memcpy(out[n],start,(size_t)len);
        out[n][len] = '\0';
        n++;
        if(*p == ','){
            p++;
            p = skip_ws(p);
            /*comma at the end with nothing following it*/
            if((*p == '\0')){
                return FALSE;
            }
        }
       
    }
     if(*p && n == max_ops){
            return FALSE;
        }
        if(out_count){
            *out_count = n;
        }
        return TRUE;
    
}
/*returns the valid adressing method for the operand*/
OperandAdressing get_op_adr_method( const char* s){

    const char* p;
    long temp;

    if(!s || *s == '\0'){
        return OP_ADR_INVALID;
    }
    if(is_register_name(s)){
        return OP_ADR_REG;
    }
    if(s[0] == '#'){
        if(parse_to_int(s+1, &temp)){
            return OP_ADR_IMMEDIATE;
        }
        return OP_ADR_INVALID;
    }
    p = s;
    while(*p && *p!='['){
        p++;
    }
    if(*p == '['){
        const char* lable_end;
        const char* p2;
        /*tow dimentional array division*/
        const char* p3 ;
        const char* p4;
        lable_end = p;
        p2 =  strchr(p+1,']');
        p3 = p2 ? strchr(p2+1,'['): 0;
        p4  = p3? strchr(p3+1,']'):0;

        if(p4){
            char matlabel[MAX_LABEL_NAME];
            int matlableLen;

            matlableLen = (int)(lable_end - s);
            if(matlableLen >= (int)(sizeof(matlabel))){
                matlableLen = (int)sizeof(matlabel)-1;
            }
            memcpy(matlabel,s,(size_t)matlableLen);
            matlabel[matlableLen]= '\0';
            if(validate_symbol_name(matlabel)){
                return OP_ADR_MAT;
            }
        }
        return OP_ADR_INVALID;
    }
    if(validate_symbol_name(s)){
        return OP_ADR_DIRECT;
    }

    return OP_ADR_INVALID;
}
/*parsing to an integer value*/
int parse_to_int(const char* s ,long* out){
    const char*p;
    int neg,any;
    long v;

    p = skip_ws(s);
    if(*p == '+' || *p == '-'){
        neg = (*p == '-');
        p++;
    }
    while(*p >= '0' && *p <= '9'){
        any = 1;
        v = v*10 + (*p - '0');
        p++;
    }
    if(!any){
        return FALSE;
    }
    if(!is_only_ws(p)){
        return FALSE;
    }
    if(neg){
        v = -v;
    }
    if(out){
        *out = v;
    }
    return TRUE;
}
