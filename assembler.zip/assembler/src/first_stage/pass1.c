#include "../../include/first_stage/pass1.h"
#include "../../include/helper/operand_utils.h"
#include "../../include/helper/utils.h"
#include "../../include/data_structs/reserved_table.h"
#include "../../include/data_structs/action_table.h"
#include "../../include/encoding/encoding_layout.h"
#include "../../include/common.h"
#include "../../include/error_a.h"

static int parse_int(const char* s, long* out, const char** next){
    const char* p = skip_ws(s);
    int neg = 0, any = 0; long v = 0;
    if (*p=='+'||*p=='-'){ neg = (*p=='-'); p++; }
    while (*p>='0' && *p<='9'){ any=1; v = v*10 + (*p - '0'); p++; }
    if (!any) return 0;
    if (neg) v = -v;
    if (out)  *out  = v;
    if (next) *next = p;
    return 1;
}
static int reg_num(const char* s){
    return is_register_name(s) ? (int)(s[1] - '0') : -1;
}

static int parse_matrix_operands(const char*s , int* row_is_reg, int* col_is_reg, int* row_val, int* col_val, const char* next){
    const char* p;
    const char* temp;
    long v;
    
    p = skip_ws(s);
    if(*p != '['){
        return FALSE;
    }
    p++;
    p = skip_ws(p);
    if(is_register_name(p)){
        *row_is_reg = TRUE;
        *row_val = (long)reg_num(p);
        p+=2;
    }
    else{
        if(!parse_int(p, &v, &temp)){
            return FALSE;
        }
        *row_is_reg = FALSE;
        *row_val = v;
        p = temp;
    }
    p = skip_ws(p);
    if(*p!=']'){
        return FALSE;
    }
    p++;

    p = skip_ws(p);
    if(*p!='['){
        return FALSE;
    }
    p++;

    p=skip_ws(p);
    if(is_register_name(p)){
        *col_is_reg = TRUE;
        *col_val = (long)reg_num(p);
        p+=2;
    }
    else{
        if(!parse_int(p,&v,&temp)){
            return FALSE;
        }
        *col_is_reg = FALSE;
        *col_val = v;
        p = temp;
    }

    p = skip_ws(p);
    if(*p!=']'){
        return FALSE;
    }
    p++;

    if(next){
        next = p;
    }
    return TRUE;
}

Pass1Res first_pass(const FileBuffer* fb,Memory* mem){
    Pass1Res res;
    int i;

    res.symbolTable = 0;
    res.error_flag = FALSE;
    mem_init(mem);

    for(i = 0; i<fb->count; i++){
        size_t len ;
        const char* line;
        const char* p;
        char w1[MAX_LINE_LENGTH],w2[MAX_LINE_LENGTH];
        int has_label;
        char label[MAX_LABEL_NAME];

        label[0] = '\0';
        line = fb->lines[i];
        p = skip_ws(line);
        has_label = FALSE;


        /*if an empty line or a comment ignore it*/
        if(*p == '\0' || *p == ';'){
            continue;
        }

        /*read first word*/
        p = read_word(p,w1,(int)sizeof(w1));
        if(w1[0] == '\0'){
            continue;
        }

        /*check if the word is a label (definition)*/

        len = strlen(w1);
        if(len > 0 && w1[len-1] == ':'){
             
            w1[len-1] = '\0';
            has_label = TRUE;
            strcpy(label, w1);

            /*if the name of the label is invalid or already exists*/
            if(!validate_symbol_name(label) || is_reserved_word(label) || find_symbol(res.symbolTable,label)){
                report_error_fb(fb," illegal label name\n",i+1);
                has_label = FALSE;
                res.error_flag = TRUE;
                
            }
            
            /*label definition must contain a value*/
            p = read_word(p,w2,(int)sizeof(w2));
            if(w2[0] == '\0'){
                report_error_fb(fb, "label without a statment", i+1);
                res.error_flag = TRUE;
                continue;
            }
        }
        /*if theres no label w1 is now */
        else{
            strcpy(w2,w1);
        }


        /*directives*/
        if(w2[0] == '.'){
            /*if its a data instruction*/
            if(strcmp(w2,".data") == 0  || strcmp(w2,".string") == 0 || strcmp(w2, ".mat") ==0 ){
                const char* q;
                const char* nums;
                long base_dc;
                long val;
                int containing_nums;

                containing_nums = FALSE;
                nums = p;
                base_dc = mem->DC;

                if(strcmp(w2,".data") == 0){

                    /*checks if there are even values after data and inserts the first one*/
                    nums = skip_ws(nums);
                    if(!parse_int(nums, &val, &q)){
                        report_error_fb(fb, " .data expects at least one integer", i+1);
                        res.error_flag = TRUE;
                    }
                    else{
                        if(!mem_insert_data_val(mem,val)){
                            report_error_fb(fb, "couldnt insert data", i+1);
                            res.error_flag = TRUE;
                        }
                        containing_nums = TRUE;
                        nums = q;
                    }
                    /*inserts all other numebr */
                    while(*nums != '\0'){
                        nums = skip_ws(nums);
                        if(*nums == ','){
                            nums++;
                            nums = skip_ws(nums);
                            if(!parse_int(nums,&val, &q)){
                                report_error_fb(fb, "expected int after comma in .data", i+1);
                                res.error_flag = TRUE; 
                                break;
                            }
                            if(!mem_insert_data_val(mem,val)){
                                report_error_fb(fb, "couldnt insert data", i+1);
                                res.error_flag = TRUE; 
                                break;
                            }
                            nums = q;
                            continue;
                        }

                        if(*nums == '\0'){
                            break;
                        }
                        if(!isspace((unsigned char)*nums)){
                            report_error_fb(fb, "extra text after .data integers is illegal",i+1);
                            res.error_flag = TRUE;
                            break;
                        }
                        while(*nums != '\0' && isspace((unsigned char)*nums)){
                            nums++;
                        }
                    }

                    if(has_label && containing_nums){
                        add_symbol(&res.symbolTable, label,base_dc,DATA_SYMBOL);
                    }
                    continue;

                }
                else if(strcmp(w2,".string") == 0){
                    const char* q;
                    long base_dc;

                    q = skip_ws(p);
                    base_dc = mem->DC;

                    if( *q != '"'){
                        report_error_fb(fb, " .string missing opening quote", i+1);
                        res.error_flag = TRUE;
                        continue;
                    }

                    q++;
                    while(*q!='\0' && *q!='"'){
                        if(!mem_insert_data_val(mem,(long)(unsigned char)(*q))){
                            report_error_fb(fb, " out of data memory" , i+1);
                            res.error_flag = TRUE;
                            break;
                        }
                        q++;
                    }

                    if( *q!='"'){
                        report_error_fb(fb, " .string missing closing quote",i+1);
                        res.error_flag = TRUE;
                        continue;
                    }

                    if(has_label){
                        add_symbol(&res.symbolTable , label, base_dc, DATA_SYMBOL);
                    }
                    continue;

                }
                else if(strcmp(w2,".mat") == 0){
                    const char* q;
                    long base_dc;
                    int rows, cols;
                    long need,k;
                    int is_rows_reg, is_cols_reg;
                    long temp;

                    q= skip_ws(p);
                    base_dc = mem->DC;

                    if(!parse_matrix_operands(q,&is_rows_reg,&is_cols_reg,&rows,&cols,q)){
                        report_error_fb(fb, " .mat expects rows and cols values",i+1);
                        res.error_flag = TRUE;
                        continue;
                    }
                    if(rows<=0 || cols <= 0){
                        report_error_fb(fb, " invalid mat dim",i+1);
                        res.error_flag = TRUE;
                        continue;
                    }
                    need = rows*cols;

                    q = skip_ws(q);
                    if(need > 0){
                        if(!parse_int(q,&temp,&q)){
                            report_error_fb(fb, " mat expects integers",i+1);
                            res.error_flag = TRUE;
                            continue;
                        }
                        if(!mem_insert_data_val(mem,temp)){
                            report_error_fb(fb, " couldnt insert data", i+1);
                            res.error_flag = TRUE;
                            continue;
                        }
                        k = 1;

                        while(k<need){
                            q = skip_ws(q);
                            
                            if(*q != ','){
                                report_error_fb(fb, " there must be a comma between values" ,i+1);
                                res.error_flag = TRUE;
                                break;
                            }
                            q++;
                            q = skip_ws(q);
                            if(!parse_int(q,&temp,&q)){
                                report_error_fb(fb, " expected integer after coma",i+1);
                                res.error_flag = TRUE;
                                break;
                            }
                            if(*q == '\0'){
                                 if(!mem_insert_data_val(mem,0)){
                                    report_error_fb(fb, " couldnt insert data",i+1);
                                    res.error_flag = TRUE;
                                    break;
                                }
                                
                            }
                            if(!mem_insert_data_val(mem,temp)){
                                report_error_fb(fb, " couldnt insert data", i+1);
                                res.error_flag = TRUE;
                                break;
                            }
                            k++;
                        }
                        q = skip_ws(q);
                        if(*q != '\0'){
                            report_error_fb(fb, " extra text after .mat initializer", i+1);
                            res.error_flag = TRUE;
                            continue;
                        }
                        if(has_label){
                            add_symbol(&res.symbolTable,label,base_dc,DATA_SYMBOL);
                        }
                    }
                 
                }
            
            }
            /*instruction*/
            else if(strcmp(w2,".extern") == 0 ){

                char labelName[MAX_LABEL_NAME];
                read_word(p,labelName,(int)(sizeof(labelName)));

                add_symbol(&res.symbolTable,labelName,0L,EXTERN_SYMBOL);
            }

            else if(strcmp(w2,".entry") == 0){
                char labelName[MAX_LABEL_NAME];
                read_word(p,labelName,(int)(sizeof(labelName)));

                add_symbol(&res.symbolTable,labelName,0L,ENTRY_SYMBOL);
            }   
            

        }
        /* regualar opcode line*/
        else{
            const Action* act;
            int need_src, need_dst, need_sum;
            char ops[2][MAX_LINE_LENGTH];
            int ops_num, words;
            int src_is_reg, dst_is_reg;
            long base_ic;
            
            OperandAdressing srcmethod, dstmethod;
            Word* memwords;


            ops_num=0;

            base_ic = mem->IC;
            act = find_action(w2);
            if(!act){
                report_error_fb(fb, "  unknown opcode",i+1);
                res.error_flag = TRUE;
                continue;
            }

            need_src = (act->src_modes != 0);
            need_dst = (act->dst_modes != 0);
            need_sum = need_dst + need_src;

            if(!parse_operands(p,ops,2,&ops_num)){
                report_error_fb(fb, "  bad operands\n",  i+1);
                res.error_flag = TRUE;
                continue;
            }
            if(ops_num != need_sum){
                report_error_fb(fb, "  too few/may operands",i+1);
                res.error_flag = TRUE;
                continue;
            }

            srcmethod = OP_ADR_INVALID;
            dstmethod = OP_ADR_INVALID;
            if(need_src){
                srcmethod = get_op_adr_method(ops[0]);
            }
            if(need_dst){
                dstmethod = get_op_adr_method(ops[1]);
            }

            if(need_src){
                if(srcmethod == OP_ADR_INVALID || (act->src_modes & adr_mask_bit(srcmethod)) == 0){
                    report_error_fb(fb, "  illegal source adressing",i+1);
                    res.error_flag = TRUE;
                    continue;
                }
            }
            if(need_dst){
                if(dstmethod == OP_ADR_INVALID || (act->dst_modes & adr_mask_bit(dstmethod)) == 0){
                    report_error_fb(fb, "  illegal dst adressing",i+1);
                    res.error_flag = TRUE;
                    continue;
                }
            }

            words = 1;
            src_is_reg = (need_src && srcmethod == OP_ADR_REG);
            dst_is_reg = (need_dst && dstmethod == OP_ADR_REG);

            if(need_src){
                if(srcmethod == OP_ADR_IMMEDIATE || srcmethod == OP_ADR_DIRECT){
                    words+=1;
                }
                else if(srcmethod == OP_ADR_MAT){
                    words+=2;
                }
            }
            if(need_dst){
                if(dstmethod == OP_ADR_IMMEDIATE || dstmethod == OP_ADR_DIRECT){
                    words+=1;
                }
                else if(dstmethod == OP_ADR_MAT){
                    words+=2;
                }
            }
            if(src_is_reg && dst_is_reg){
                words+=1;
            }
            else if(src_is_reg || dst_is_reg){
                words+=1;
            }

            if(has_label){
                if(!add_symbol(&res.symbolTable, label, base_ic,CODE_SYMBOL)){
                    res.error_flag = TRUE;
                }
            }


            /*reserve words*/
            if(!mem_reserve_code(mem,words)){
                report_error_fb(fb, "  out of  code memory", i+1);
                res.error_flag = TRUE;
                continue;
            }

            memwords = mem_code_at(mem,mem->IC);
            set_bits(memwords,BVU);
            set_filed(memwords,OPCODE_START_BIT,OPCODE_BIT_LENGTH,(unsigned)act->opcode);
            set_filed(memwords, SRC_ADR_START_BIT, OPERANDS_BIT_LENGTH, need_src ?srcmethod:0u);
            set_filed(memwords,DST_ADR_START_BIT,OPERANDS_BIT_LENGTH,need_dst? dstmethod:0u);
            set_filed(memwords,ARE_START_BIT,ARE_BIT_LENGTH,ARE_ABS);
            mem->IC+=words;


            
        }
    }
    mem->ICF = mem->IC;
    mem->DCF = mem->DC;

    return res;
}