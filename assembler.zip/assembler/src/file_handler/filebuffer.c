#include "../../include/file_handler/filebuffer.h"
#include "../../include/error_a.h"
#include "../../include/common.h"
#include "../../include/helper/utils.h"
#include <limits.h>
static int ensure_capacity(FileBuffer* fb, int wanted_cap){
    int new_cap;
    char** temp;
    if(fb->capacity >= wanted_cap){
        return TRUE;
    }
    new_cap = (fb->capacity == 0) ? CAP_INIT_SIZE: fb->capacity*2;
    while(new_cap < wanted_cap){
        new_cap *=2;
    }
    temp = (char**)realloc(fb->lines,(size_t)new_cap* sizeof(char*));
    if(!temp){
        report_error_fb(fb,"Couldn't Allocate Memory");
        fb_free(fb);
        free(temp);
        return FALSE;
    }
    fb->lines = temp;
    fb->capacity = new_cap;
    return TRUE;
}

/*
static int is_comment_or_empty_line(const char* s){
    const unsigned char* p;
    p = (const unsigned char*)s;
    while(*p && isspace(*p)){
        p++;
    }
    if(*p == '\0'){
        return TRUE;
    }
    if(*p == ';'){
        return TRUE;
    }
    return FALSE;

}
*/

/*
    initializes the buffer with default values
*/
int init_fb(FileBuffer* fb, const char* filename, const char* ext){
    fb->lines = 0;
    fb->count = 0;
    fb->capacity =0;
    fb->og_current_line_number = 0;
    fb->error_flag = FALSE;
    fb->filename = filename;
    fb->ext = ext;

    return TRUE;

}
/*
    clears the lines and details in the buffer
*/
void clear_fb(FileBuffer* fb){

    int i;
    if(!fb){
        return;
    }
    if(fb->lines){
        for(i =0; i<fb->count;i++){
            free(fb->lines[i]);
        }
        free(fb->lines);
    }
    fb->lines = 0;
    fb->count = 0;
    fb->capacity = 0;
}
/*
    add a new line to the buffer
*/
int fb_push_line(FileBuffer* fb, const char* srcline, int og_line_number){
    char* p;
    if(!ensure_capacity(fb,fb->count+1)){
        return FALSE;
    }
    p = safe_copy_line(srcline);
    fb->lines[fb->count++] = p;
    return TRUE;
}


/*
    read file into buffer
*/
int fb_read_source(FileBuffer* fb, const char* filepath){
    FILE* fp ;
    char buf[MAX_LINE_LENGTH + 2];
    int line_num;

    fp = fopen(filepath, "r");
    line_num = 0;


    if(fp == NULL){
        fb->og_current_line_number = 0;
        report_error_fb(fb,"Cannot open input file");
        return FALSE;
    }

    while(fgets(buf,sizeof(buf),fp)!=0){
        char* temp_line;
        size_t len;
        int c;
        int too_long;

        line_num++;

        /*check if the line is inside the buffer or longer */
        temp_line = strchr(buf, '\n');
        too_long = (temp_line == 0)? 1:0;
        if(temp_line != FALSE){
            *temp_line = '\0';
        }
        else{
            /*empty till the next line*/
              do{
                c=fgetc(fp);
            }while(c!= '\n' && c!= EOF);
        }

        len = strlen(buf);
        if(too_long || len > MAX_LINE_LENGTH){
            fb->og_current_line_number = line_num;
            report_error_fb(fb, "Line is too long");

            continue;
        }
        fb_push_line(fb,buf,line_num);
    }

    fclose(fp);
    return TRUE;


}
/*
    attaches the file name and ext in a format
*/
void make_input_path(char* out, size_t out_size, const char* basename, const char* ext){
    size_t n1,n2,need;
    n1 = strlen(basename);
    n2 = strlen(ext);
    need = n1+n2 +1;

    if(out_size < need){
        if(out_size){
            out[0] = '\0';
            return;
        }
    }
    memcpy(out, basename,n1);
    memcpy(out + n1,ext, n2 + 1);
}

/*
    writes buffer conent into a .ext file
*/
int fb_write_to_ext(FileBuffer* fb, const char* ext){
    char path[PATH_MAX];
    FILE* fp;
    int i;

    make_input_path(path,sizeof(path), fb->filename, ext);

    fp = fopen(path, "w");
    if(fp == NULL){
        report_error_fb(fb,"Cannot open input file");
        fb->error_flag = TRUE;
        return FALSE;
    }
    for(i=0;i<fb->count; i++){
        fputs(fb->lines[i],fp);
        fputc('\n',fp);
    }
    fclose(fp);
    return TRUE;




}
/*
    creates a new file buffer with ext and filename
*/
FileBuffer* fb_new(const char* filename, const char* ext){
    FileBuffer* fb;
    fb = (FileBuffer*)malloc(sizeof(FileBuffer));
    init_fb(fb,filename,ext);
    return fb;
}
/*
    frees allocated memory of buffer
*/
void fb_free(FileBuffer* fb){
    if(!fb){
        return;
    }
    clear_fb(fb);
    free(fb);
}
