#include "../../include/data_structs/reserved_table.h"
#include "../../include/data_structs/action_table.h"
#include "../../include/common.h"

DirectiveType directive_type(const char* s){
    if(!s){
        return NO_DIR;
    }
    if(strcmp(s,".data") == 0){
        return DATA_DIR;
    }
    if(strcmp(s,".string") == 0){
        return STRING_DIR;
    }
    if(strcmp(s,".mat") == 0){
        return MAT_DIR;
    }
    if(strcmp(s,".entry") == 0){
        return ENTRY_DIR;
    }
    if(strcmp(s,".extern") == 0){
        return EXTERN_DIR;
    }
    return NO_DIR;
}
int is_directive(const char* s){
    return directive_type(s) != NO_DIR;
}
int is_register_name(const char* s){
    return s && s[0] == 'r' && s[1]>='0' && s[1]<='7' && isspace(s[2]);
}
int is_reserved_word(const char* s){
    return is_opcode(s) || is_directive(s) || is_register_name(s);
}