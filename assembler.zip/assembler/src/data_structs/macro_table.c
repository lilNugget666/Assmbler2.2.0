#include "../../include/data_structs/macro_table.h"
#include "../../include/error_a.h"
#include "../../include/helper/utils.h"
#include "../../include/common.h"

static int ensure_cap(Macro* m, int wanted){
    int new_cap;
    char** temp;
    if(m->capacity >= wanted){
        return TRUE;
    }

    new_cap = (m->capacity == 0)?  CAP_INIT_SIZE : m->capacity*2;
    while(new_cap < wanted){
        new_cap *=2;
    }
    temp = (char**)realloc(m->lines, (size_t)new_cap * sizeof(char*));
    if(!temp){
        fprintf(stderr, "ERROR: couldnt allocate memory\n");
        free(m);
        free(temp);
        return FALSE;
    }
    m->lines = temp;
    m->capacity = new_cap;
    return TRUE;
}
/*
    initialization of the table with default values
*/
void macro_table_init(Macro** head){
    *head = 0;
}
void macro_table_free(Macro** head){
    Macro* p; 
    int i;
    p = *head;

    while(p){
        Macro* q = p->next;
        if(p->name){
            free(p->name);
        }
        if(p->lines){
            for(i = 0; i<p->count; i++){
                free(p->lines[i]);
            }
            free(p->lines);
            i=0;
        }
        free(p);
        p=q;
        
    }
    *head = 0;
}

/*
    locate a macro in the table by its name
    returns a pointer to it if found
*/
Macro* find_macro(Macro* head, const char* name){
    Macro* p; 
    p = head;
    while(p){
        if(strcmp(p->name, name) == 0){
            return p;
        }
        p = p->next;
    }
    return NULL;
}

/*
    inserts a macro to the table 
*/
Macro* add_macro(Macro** head, const char* name, long definition_line){
    Macro* m;
    m = (Macro*)malloc(sizeof(Macro));
    m->name = safe_copy_line(name);
    m->lines = 0;
    m->count =0;
    m->capacity = 0;
    m->definition_line = definition_line;
    m->next = *head;
    *head = m;
    return m;
}
/*
    adds a line to the macro lines
*/
int macro_add_line(Macro* mcro, const char* src){
    char* temp;
    if(!ensure_cap(mcro, mcro->count+1)){
        return FALSE;
    }
    temp = safe_copy_line(src);
    mcro->lines[mcro->count++] = temp;
    return TRUE;
}


