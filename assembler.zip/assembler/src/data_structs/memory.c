#include "../../include/data_structs/memory.h"
#include "../../include/data_structs/word.h"
#include "../../include/encoding/encoding_layout.h"
#include "../../include/common.h"

/*initialize memory*/
void mem_init(Memory* m){
    int i;
    m->IC = IC_START_POINT;
    m->DC = 0;
    m->ICF = 0;
    m->DCF = 0;
    for(i =0; i< MEM_CAP;i++){
        set_bits(&m->memory[i],BVU);
    }
}
/*free memory*/
void mem_clear(Memory* m){
    mem_init(m);
}

/*reserve words for codeing, advances ic*/
int mem_reserve_code(Memory* m, int words){
    int i;
    if(words < 0){
        return FALSE;
    }
    if(m->IC + words > MEM_CAP){
        return FALSE;
    }
    for(i = 0; i<words;i++){
        set_bits(&m->memory[m->IC + i],BVU);
    }
    m->IC += words;
    return TRUE;
}

/*returns the code at idx (idx+100)*/
Word* mem_code_at(Memory* m , int idx){
    if(idx < 0 || idx +IC_START_POINT >= m->IC){
        return NULL;
    }
    return &m->memory[idx+IC_START_POINT];
}
/*returns the data at idx*/
Word* mem_data_at(Memory* m, int idx){
    if(idx < 0 || idx> m->DC){
        return NULL;
    }
    return &m->memory[idx];
}

/*insert a value into the memory*/
int mem_insert_data_val(Memory* mem, unsigned int val){
    if(mem->DC >= MEM_CAP){
        return FALSE;
    }
    set_filed(&mem->memory[mem->DC],ARE_START_BIT,ARE_BIT_LENGTH, ARE_ABS);
    set_filed(&mem->memory[mem->DC],DST_ADR_START_BIT, 8, val);
    mem->DC +=1;
    return TRUE;
}

/*get code img*/
long mem_code_img(const Memory* m){
    return m->ICF;
}
/*get data img*/
long mem_data_img(const Memory* m){
    return m->DCF;
}


