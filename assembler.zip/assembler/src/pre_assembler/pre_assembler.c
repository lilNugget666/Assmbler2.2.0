#include "../../include/pre_assembler/pre_assembler.h"
#include "../../include/data_structs/macro_table.h"
#include "../../include/error_a.h"
#include "../../include/helper/utils.h"
#include "../../include/data_structs/reserved_table.h"



FileBuffer* pre_assembler_process(FileBuffer* fb){
    Macro* table = 0;                                        // (keep)
    FileBuffer* outputfile;
    int i;                                                   // FIX: j,k not needed here

    outputfile = fb_new(fb->filename, ".am");
    outputfile->error_flag = fb->error_flag;
    macro_table_init(&table);

    for (i = 0; i < fb->count; i++){
        const char* templine;
        const char* p;
        char first_word[MAX_MACRO_NAME], name[MAX_MACRO_NAME];

        templine = fb->lines[i];
        fb->og_current_line_number = i + 1;

        p = read_word(templine, first_word, (int)sizeof(first_word));
        /* copy empty line through */
        if (first_word[0] == '\0'){
            fb_push_line(outputfile, templine, fb->og_current_line_number);
            continue;
        }

        /* ----- detect declaration ----- */
        if (strcmp(first_word, "mcro") == 0){
            Macro* m;

            /* read macro name */
            p = read_word(p, name, (int)sizeof(name));
            if (name[0] == '\0'){
                report_error_fb(fb, "Macro requires a name");
                continue;
            }
            if (!is_only_ws(p)){
                report_error_fb(fb, "Extra text after macro header is not allowed");
                continue;
            }
            /* name validation */
            if (!valid_macro_name(name)){
                report_error_fb(fb, "Macro name is invalid");
                continue;
            }
            if (is_reserved_word(name)){
                report_error_fb(fb, "Illegal macro name (reserved)");
                continue;
            }
            if (find_macro(table, name)){
                report_error_fb(fb, "Macro already exists");
                continue;
            }

            m = add_macro(&table, name, fb->og_current_line_number);
            m->definition_line = i;

            /* collect body lines until mcroend (exclusive) */
            i++;
            for (;;){
                if (i >= fb->count){
                    report_error_fb(fb, "Unexpected end of file: missing 'mcroend'");
                    break;
                }

                templine = fb->lines[i];
                p = read_word(templine, first_word, (int)sizeof(first_word));

                if (strcmp(first_word, "mcroend") == 0){
                    if (!is_only_ws(p)){
                        report_error_fb(fb, "'mcroend' line should contain only whitespace");
                    }
                    /* FIX: do NOT include mcroend in body, do NOT i++ here.
                       We break; the outer for-loop's i++ will move past mcroend. */
                    break;
                }

                macro_add_line(m, templine);
                i++;
            }

            continue;
        }

        /* stray mcroend */
        if (strcmp(first_word, "mcroend") == 0){
            report_error_fb(fb, "mcroend with no matching mcro definition");
            continue;
        }


        {
            Macro* temp = find_macro(table, first_word);
            if (temp){
                int j;
                for (j = 0; j < temp->count; j++){
                    fb_push_line(outputfile, temp->lines[j], fb->og_current_line_number);
                }
                continue;                                               // FIX: don't also push the raw token line
            }
        }

        /* passthrough (non-macro) line */
        fb_push_line(outputfile, templine, fb->og_current_line_number);
    }

    return outputfile;
}