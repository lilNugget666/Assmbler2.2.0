
#include "include/common.h"
#include "include/file_handler/filebuffer.h"
#include "include/error_a.h"
#include "include/pre_assembler/pre_assembler.h"
#include <limits.h>

static void usage(const char* prog)
{
    fprintf(stderr, "Usage: %s <file1> [file2 ...]\n", prog);
    fprintf(stderr, "  (without extension; the program will read <file>.as)\n");
}
int main(int argc, char** argv){
    /*FILE* fp1;
    char ch;

fp1 = fopen("/tmp/tmp.ey1hYS4QG5/assembler/cmake-build-default/working_macro.as", "r");
    if(fp1 == NULL) {
        fprintf(stderr, "Error opening file!\n");
    }
    while((ch=fgetc(fp1)) != EOF) {
        putchar(ch);
    }
    fclose(fp1);
    return 0;*/


    int i;
    if(argc<2){
        usage(argv[0]);
        return EXIT_FAILURE;
    }

    for( i=1; i<argc; i++){
        FileBuffer fb;
        FileBuffer* outputbuff;
        char path[PATH_MAX];


        outputbuff = NULL;

        init_fb(&fb, argv[i],".as");
        snprintf(path, sizeof(path), "%s%s", fb.filename,fb.ext);
        printf("%s",path);
        fb_read_source(&fb,path);

        outputbuff = pre_assembler_process(&fb);

        if(!fb.error_flag && !outputbuff->error_flag){
            fb_write_to_ext(outputbuff, ".am");
        }
        else{
            fprintf(stderr,"No output file produced for %s due to errors.\n",outputbuff->filename);
        }

        fb_free(outputbuff);
        clear_fb(&fb);



    }


    return EXIT_SUCCESS;



}