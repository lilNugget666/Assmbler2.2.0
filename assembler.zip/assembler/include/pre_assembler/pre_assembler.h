#ifndef PRE_ASSEMBLER_H
#define PRE_ASSEMBLER_H

#include "../file_handler/filebuffer.h"

/*
    implementation of the pre assembler process
    returns a pointer to the output file buffer
*/
FileBuffer* pre_assembler_process(FileBuffer* fb);

#endif /*PRE_ASSEMBLER_H*/