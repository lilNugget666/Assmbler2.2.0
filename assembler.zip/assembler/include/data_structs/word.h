#ifndef WORD_H
#define WORD_H

#include "../common.h"

#define WORD_BITS 10

typedef enum{
    BV0 = 0, /*0 bit val*/
    BV1 = 1, /* 1 bit val*/
    BVU = 2 /*unknown / unset bit val*/
}BVal;

typedef struct{
    unsigned char word[WORD_BITS];
}Word;

/*
    sets all bits to v
*/
void set_bits(Word* w, BVal v);
/* returns 1 if there are 1 or more unknown values*/
int are_there_unkown(const Word* w);

/* sets the bit in idx to v*/
int set_bit(Word* w, int idx, BVal v);
/*get bits value in idx */
BVal get_bit(Word* w, int idx);

/*returns the value of a range of bits to out, rerturn value indicates sucess*/
int get_field(Word* w, int start, int len, unsigned int* out);

/*sets the value in the range to val*/
int set_filed(Word* w, int start, int len, int val);

#endif