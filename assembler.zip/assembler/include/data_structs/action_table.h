#ifndef ACTION_TABLE_H
#define ACTION_TABLE_H

#include "../common.h"
#include "../helper/operand_utils.h"

#define IMMEDIATE_ADR 0
#define DIRECT_ADR 1
#define MAT_ADR 2
#define REG_ADR 3

#define ALL_ADR (IMMEDIATE_ADR | DIRECT_ADR | MAT_ADR | REG_ADR)
#define ADR_1_3 (DIRECT_ADR | MAT_ADR | REG_ADR)
#define ADR_1_2 (DIRECT_ADR |MAT_ADR)
#define NO_ADR -1

#define NUM_OF_ACTIONS 16

typedef struct{
    const char* name;
    int opcode;
    int src_modes;
    int dst_modes;
}Action;

const Action* find_action(const char* name);

/*returns 1 if opcode name, 0 otherwise*/
int is_opcode(const char* s);
int adr_mask_bit(OperandAdressing m);
#endif