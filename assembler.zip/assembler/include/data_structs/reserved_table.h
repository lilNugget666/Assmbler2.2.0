#ifndef RESERVED_TABLE_H
#define RESERVED_TABLE_H

#include "../common.h"

typedef enum{
    NO_DIR= 0,
    DATA_DIR,
    STRING_DIR,
    MAT_DIR,
    ENTRY_DIR,
    EXTERN_DIR

}DirectiveType;


DirectiveType directive_type(const char* s);
int is_directive(const char* s);
int is_register_name(const char* s);
int is_reserved_word(const char* s);

#endif