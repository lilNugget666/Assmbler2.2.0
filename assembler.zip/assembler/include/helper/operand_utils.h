#ifndef OPERAND_UTILS_H
#define OPERAND_UTILS_H

#include "../common.h"
#include "../data_structs/action_table.h"

/*splits the operands into an array (out)*/
int parse_operands(const char* s, char out[][MAX_LINE_LENGTH],int max_ops, int* out_count);
/*returns the valid adressing method for the operand*/
OperandAdressing get_op_adr_method( const char* s);
/*parsing to an integer value*/
int parse_to_int(const char* s ,long* out);

#endif