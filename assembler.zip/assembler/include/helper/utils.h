/*
copies a line and allocates memory if needed
*/
#ifndef UTILS_H
#define UTILS_H

char* safe_copy_line(const char* s);
/*skips leading white spaces*/
const char* skip_ws(const char* line);
/*checks if a line contains only white spaces*/
int is_only_ws(const char* line);
/*reada the next word in the line (stoppes at ws)*/
const char* read_word(const char* line, char* out, int out_size);
/*reads until a specific char*/
char* read_till_char(const char* line,char sign);

/*checks if c is a letter*/
int is_alpha(int c);
/*checks if c is a numebr*/
int is_num(int c);
/*checks if numric or alpha*/
int is_alnum(int c);
/*validates a macro name*/
int valid_macro_name(const char* line);

#endif /*UTILS_H*/
