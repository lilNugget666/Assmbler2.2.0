#ifndef COMMON_H
#define COMMON_H


/*basic libs ansi*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#define MAX_LINE_LENGTH 80
#define TEMP_BUFF_INIT_SIZE 16
#define CAP_INIT_SIZE 16
#define TRUE 1
#define FALSE 0
#define ALLOC_ERR -1
#define MAX_MACRO_NAME 30
#define MAX_LABEL_NAME 30


typedef enum{
    OP_ADR_INVALID = -1,
    OP_ADR_IMMEDIATE = 0,
    OP_ADR_DIRECT = 1,
    OP_ADR_MAT = 2,
    OP_ADR_REG = 3
}OperandAdressing;


typedef enum{
    ARE_ABS = 0,
    ARE_EXT = 1,
    ARE_REL = 2
}ARE;

#endif