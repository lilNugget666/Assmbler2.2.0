#ifndef ERROR_A_H
#define ERROR_A_H

#include "file_handler/filebuffer.h"

/*
    prints and reports the error. (doesnt stop the run)
    
*/
int report_error_fb(FileBuffer* fb, const char* msg);



#endif