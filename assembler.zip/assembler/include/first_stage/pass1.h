#ifndef PASS1_H
#define PASS1_H

#include "../common.h"
#include "../file_handler/filebuffer.h"
#include "../data_structs/symbol_table.h"
#include "../data_structs/memory.h"

/*pass 1 has no output file, this will indicate errors in it*/
typedef struct{
    Symbol* symbolTable;
    int error_flag;
}Pass1Res;

Pass1Res first_pass(const FileBuffer* fb,Memory* mem);


#endif 